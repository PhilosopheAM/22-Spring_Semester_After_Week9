function popChromo = GA_init_popChromo(POPNUM,CHROMOLEN)
    for i = 1:POPNUM
        chromos = [];
        for j = 1:CHROMOLEN
            chromos(1,j) = rand;
            chromos(2,j) = rand;
        end
        popChromo{i} = chromos;
    end
end