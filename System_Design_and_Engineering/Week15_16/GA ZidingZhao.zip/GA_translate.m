function trait = GA_translate(chromo,INTLEFT,INTRIGHT)
    unit = (INTRIGHT-INTLEFT)/size(chromo,2); % calculat unit, (R-L)/CHOROMOLEN = (R-L)/size(chromo,2)
    trait = 0;
    for i = 1:size(chromo,2)
        trait = trait + chromo(i)*unit; % gene * unit
    end
    trait = trait + INTLEFT;
end