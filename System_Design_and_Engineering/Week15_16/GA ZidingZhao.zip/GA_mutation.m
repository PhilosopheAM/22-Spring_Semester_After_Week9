function filialChromo = GA_mutation(filialChromo,MUTATIONRATE)
    for i = 1:size(filialChromo,2)
        if rand < MUTATIONRATE
            chromo = filialChromo{i}(1,:);

            location = ceil(size(chromo,2)*rand);
            chromo = [chromo(1:location-1) rand chromo(location+1:end)];
            filialChromo{i}(1,:) = chromo;
        end
        if rand < MUTATIONRATE
            chromo = filialChromo{i}(2,:);
            
            location = ceil(size(chromo,2)*rand);
            chromo = [chromo(1:location-1) rand chromo(location+1:end)];
            filialChromo{i}(2,:) = chromo;
        end
    end
end