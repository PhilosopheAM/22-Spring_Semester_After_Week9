function parentsChromo = GA_selection(popChromo, popFitness, SELECTRATE)
    fitnessSum=sum(popFitness(:));%计算所有种群的适应度
    
    accumP=cumsum(popFitness/fitnessSum);%累积概率
    %轮盘赌选择算法
    for n=1:round(SELECTRATE*size(popChromo,2))
        indices=find(accumP>rand); %找到比随机数大的累积概率
        if isempty(indices)
            continue
        end
        parentsChromo(:,n)=popChromo(:,indices(1));%将首个比随机数大的累积概率的位置的个体遗传下去
    end
end