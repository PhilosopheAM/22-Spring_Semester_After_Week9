function popX = GA_decode_popChromo(popChromo,INTLEFT,INTRIGHT)
    for i = 1:size(popChromo,2)
        x1 = GA_translate(popChromo{i}(1,:),INTLEFT,INTRIGHT);
        x2 = GA_translate(popChromo{i}(2,:),INTLEFT,INTRIGHT);
        popX(:,i) = [x1,x2];
    end
end