function meshZ = GA_mesh_func(x)
    [x1,x2] = meshgrid(x(1,:),x(2,:));
    meshZ = x1.*sin(3.*x1) + x2.*sin(3.*x2);
end
