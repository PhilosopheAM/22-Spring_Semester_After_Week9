func = @(x)-(x(1)*sin(3*x(1)) + x(2)*sin(3*x(2)));
interval = [-1,2];
options = optimset('PlotFcns',@optimplotfval);
[x,fval] = fminsearch(func,interval,options);
disp(x);
disp(-fval);