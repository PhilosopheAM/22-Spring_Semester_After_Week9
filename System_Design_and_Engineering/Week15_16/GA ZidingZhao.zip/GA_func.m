function z=GA_func(x)
    z = [];
    for i = 1:size(x,2)
        z(:,i) = (x(1,i)*sin(3*x(1,i)) + x(2,i)*sin(3*x(2,i)));
    end
end