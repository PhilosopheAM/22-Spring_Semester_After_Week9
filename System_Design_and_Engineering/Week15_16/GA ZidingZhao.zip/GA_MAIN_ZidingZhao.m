% POPNUM = 100;
% INTLEFT = -1;
% INTRIGHT = 2;
% CHROMOLEN = 4;
% ITERATOIN = 1000;
% CROSSOVERRATE = 0.7;
% SELECTRATE = 0.5;
% MUTATIONRATE = 0.001;

POPNUM = 1000;
INTLEFT = -1;
INTRIGHT = 2;
CHROMOLEN = 2;
ITERATOIN = 1000;
CROSSOVERRATE = 0.7;
SELECTRATE = 0.5;
MUTATIONRATE = 0.01;

popChromo = GA_init_popChromo(POPNUM,CHROMOLEN);
popX = GA_decode_popChromo(popChromo,INTLEFT,INTRIGHT);

x_mesh(1,:)=linspace(-1,2,1000);
x_mesh(2,:)=linspace(-1,2,1000);
z_mesh=GA_mesh_func(x_mesh);
mesh(x_mesh(1,:),x_mesh(2,:),z_mesh); % (1*n, 1*n, n*n mesh)
hold on
popFunc = GA_func(popX);
scatter3(popX(1,:),popX(2,:),popFunc,'filled') % (1*n, 1*n, 1*n)
hold off
title('Initial Population');

elitesFitness = zeros(1, ITERATOIN);
for i = 1:ITERATOIN
    popFitness = GA_fitness(popX); % 1*n

    [elitesFitness(i), elitePosition] = max(popFitness(:));
    eliteX = popX(:,elitePosition);
    eliteChromo = popChromo{elitePosition};

    popChromo = GA_selection(popChromo,popFitness,SELECTRATE); % select and kill

    filialChromo = GA_crossover(popChromo,POPNUM,CROSSOVERRATE);

    filialChromo = GA_mutation(filialChromo,MUTATIONRATE);

    popChromo = {popChromo{1:end-1} eliteChromo filialChromo{:}};
    popX = GA_decode_popChromo(popChromo,INTLEFT,INTRIGHT);
end
figure
x_mesh(1,:)=linspace(-1,2,1000);
x_mesh(2,:)=linspace(-1,2,1000);
z_mesh=GA_mesh_func(x_mesh);
mesh(x_mesh(1,:),x_mesh(2,:),z_mesh); % (1*n, 1*n, n*n mesh)
hold on
popFunc = GA_func(popX);
scatter3(popX(1,:),popX(2,:),popFunc,'filled') % (1*n, 1*n, 1*n)
hold off
title('Final Population');

figure
plot(linspace(1,size(elitesFitness,2),size(elitesFitness,2)), elitesFitness);

% disp(['Solution：' num2str(max(m_Fx(pop)))]);
disp(eliteX);
disp(GA_func(eliteX));